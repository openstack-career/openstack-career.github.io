In this package, the following data we used in our study are included:
- transitionDataFulltime.csv
	This file contains the groups each fulltime contributor is identified as per period. The format is <contributor id>;<group period 1>;<group period 2>;... etc.
	The possible groups are: x - inactive, d - developer, r - reviewer and c- core.
- transitionDataNonFulltime.csv
	Same as transitionDataFulltime.csv but for contributors not identified as fulltime contributors.
- transitionDataFulltime20.csv (not used in the nier paper, but is used in my original paper)
	Same as transitionDataFulltime.csv but for a different definition of the reviewer group. In transitionDataFulltime.csv reviewers are contributors
	with at least 1 review in the period, in this file reviewers are contributors with at least 20 reviews in that period.
- nrCoreStart.csv
	Column format: <contributor id>;<number of times this person entered the core group>
- behaviorChange.csv
	This file contains info on how the activity of core contributors changes after they become part of the core group. Periods are t-2, t-1, t, t+1, t+2, t+3
	where t is the period in which core status was gained. This counts the number of commits and the number of review threads that was voted in.
	Column format: <contributor id>;<#commits t-2>;...;<#commits t+3>;<#reviews t-2>;...;<#reviews t+3>;
- coreTimings.csv
	This file contains time data on how long a contributor was developer or reviewer before/after becoming a core member.
	Column format: <contributor id>;<#periods dev before core>;<#periods reviewer before core>;<#periods core>;<#periods reviewer after core>;<#periods developer after core>
